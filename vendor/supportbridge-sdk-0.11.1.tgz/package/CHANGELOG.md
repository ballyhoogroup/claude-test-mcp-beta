# Changelog

## Unreleased

## 0.11.1

- Release the accumulated Development SDK identity, offer-display, lifecycle, and diagnostics updates.

## 0.11.0

- Adds `SupportBridge.installFromEnv()`, optional identity resolution, `support.registerTool()`, and explicit `assist` / `observe-only` runtime modes for stateless and headless MCP servers.
- Adds provider-neutral OAuth/OIDC identity adapter factories that preserve only vendor-approved, verified profile fields.
- Adds negotiated durable offer delivery with atomic leases, attachment receipts, lease-expiry requeueing, and automatic fallback to the legacy endpoint on older control planes.
- Adds a 32-case compatibility matrix proving vendor results survive missing identity, absent MCP App support, older control planes, SupportBridge network failure, and observation-only operation.

## 0.10.0

- Default to an authoritative eight-tool catalog with safe SDK-owned registration replacement.
- Breaking default: omitted `toolProfile` now selects `"streamlined"`. Legacy aliases and policy-builder tools require explicit `toolProfile: "compatibility"`; streamlined plus an enabled policy app is rejected.
- Adds immutable manifest v1 shared by installation, capability telemetry, generated App2 expectations, documentation and regression tests.
- Tracks only public registration handles owned by SupportBridge. Same-server reinstalls remove obsolete SDK tools/resources, retire background work and retain business tools. Unsupported removal and unowned collisions fail safely.
- Makes `close()` idempotent and unregisters owned handles, aborts policy sync, removes signal listeners and drains telemetry. Discovery change notifications are best effort.
- App2 displays manifest/profile details and warns on missing, stale, unknown or unexpected catalogs. Doctor diagnostics no longer attest a running server's tools.
- Adds exact default/compatibility discovery, cross-module upgrade, chat lifecycle and packed-consumer tests (eight SDK plus four unchanged business tools), including the packaged doctor CLI.
- Gives offer cards profile-specific resource URLs so a profile switch cannot reuse a cached obsolete confirmation alias; custom chat URIs no longer collide with the separate offer resource.
- Upgrades from SDK 0.9.x require a fresh MCP server instance and host rediscovery. See `docs/upgrading-0.10.0.md`.

## 0.9.15

- Brands the MCP App offer card with the offering company name, uses the SupportBridge green accent, and labels the primary action “Chat with support.”
- Releases #7 through one shared localhost/App2 product profile and enforces nonblocking delivery with explicit acceptance.
- Fixes wide-screen Live user detail scrolling and verifies no-account manual offers in production-mode API and browser tests.
- Coordinates SDK and App2 versions, validates the production container, and blocks npm publishing unless the deployed commit, source, UI assets and feature profile match.
- Keeps unreviewed presentation variants and local administrative/CRM experiments out of the release profile.

## 0.9.14

- Adds an MCP App offer card that keeps optional-support copy out of model-visible tool text and transitions directly into the embedded live chat after the user connects.
- Enables the reviewed card through a dedicated App2 production flag while keeping all other offer-presentation experiments localhost-only.
- Prevents ordinary vendor results from revealing the embedded support surface; the card appears only for a valid offer and a chat appears only after explicit acceptance.
- Enables optional manual assistance and MCP-tool acceptance in the App2 production blueprint; account association remains optional.
- Keeps full-width Live user details bounded to the application viewport so the profile body scrolls independently.

## 0.9.13

- Refreshes the embedded support chat and policy-builder UI with responsive layouts, clearer states, keyboard-safe menus, retained failed drafts, and consistent accessibility foundations.

- Publishes the remaining SDK identity, telemetry, offer-resolution, diagnostics, sanitization, and fail-open reliability updates that were previously tested only in the local checkout.
- Updates App2 with the approved SupportBridge rebrand, consolidated design tokens and components, responsive phone/tablet layouts, accessible dialogs and navigation, clearer Inbox and Live Visitor workflows, and complete local visual-regression coverage.
- Adds CRM-aware session context experiments, improved natural-language policy drafting, reasoning review controls, unified offer lifecycle presentation, Slack configuration improvements, and production credential/persistence safeguards. Local-only Demo CRM and Master Admin protections remain enforced.

## 0.9.12

- Security: chat reads, messages, end, and reopen now forward server-resolved user identity. `SupportBridge.install()` uses its existing `identify` callback; direct chat-app/control-plane callers must supply identity. See `docs/upgrading-0.9.12.md` before deploying the hardened control plane.
- Redacts credentials from agent errors, error objects, and telemetry error details, including Slack, SupportBridge, GitHub, and credential-bearing URLs.
- App2 adds fail-closed production credential checks and PostgreSQL save/recovery handling. These server changes require a separately coordinated deployment and do not enable production Master Admin or onboarding.
- Adds non-blocking medium assistance notices while preserving business-tool results and keeping acceptance explicit.
- Fixes policy-offer identity tracking and acceptance recovery so a created support chat is not reported as a failed acceptance after local state loss.
- Improves scoped offer resolution, cached-offer handling, and confirmation/chat UI states.
- Normalizes text-policy equality and contains matching for case and surrounding whitespace; regular expressions remain unchanged.
- Adds regression coverage for offer delivery, acceptance, chat confirmation, and text matching.
- Requires compatible Control Plane configuration for MCP-tool acceptance. Control Plane dashboard changes are deployed separately and are not included in this npm package.

## 0.9.11

- Adds SDK compatibility for capability-negotiated optional assistance, neutral offer notices, and same-origin confirmation responses while preserving business-tool results and schemas.
- Records control-plane offer acceptance only after a conversation is created; preserves acceptance telemetry for standalone SDK integrations.
- Improves App2 offer expiry and backend eligibility, scoped Live Visitor recommendation links, connection and account labels, Slack setup guidance, and responsive dashboard controls and dialogs.
- Includes localhost-only Slack credential settings, invite-only onboarding, and Master Admin previews. These remain disabled in production; the optional-assistance preview remains off by default.
- Does not enable production platform-owner authentication, public onboarding, or production-readiness migrations.

## 0.9.10

- Adds opt-in business-tool metadata, allowlisted argument/result capture, and application-supplied intent summaries without adding MCP tools.
- Adds explicit conversation identity for reasoning evidence; unknown conversation boundaries use the current call rather than combining unrelated chats.
- Adds App2 R1 model-versus-local comparisons, secure workspace model connections, diagnostic evidence, retryable cooldown handling, and evaluation feedback.
- Adds named workspace review-guidance cards with on/off toggles, per-MCP scope, revision checks, and locked safety rules. Matching cards share one model evaluation and cannot authorize alerts or offers.
- Improves App2 navigation, typography, responsive controls, notifications, Slack delivery infrastructure, and support intake. Notification delivery remains dry-run by default.
- Preserves existing SDK support chat and manual-offer behavior. Model settings and guidance are configured separately in each deployed App2 workspace.

## 0.9.9

- Adds App2 system policies and a shared intervention lifecycle across built-in policies, customer policies, manual intervention, and representative-approved reasoning recommendations.
- Adds the staged R1–R3 reasoning recommender with privacy-safe evidence, confidence floors, deduplication, deterministic-policy precedence, unstaffed routing, representative assignment, and explicit approval before any MCP user offer.
- Hardens the App2 control plane for real teams with per-user sessions and presence, PostgreSQL persistence support, quieter audit logs, integration diagnostics, customer history, denser responsive operational screens, notifications, and improved inbox and settings workflows.
- Adds availability-aware offline support routing: automatic triggers remain private when the team is unavailable, while explicit support requests can create queued conversations with Slack and email notification fallbacks.
- Preserves the full queued-state connecting panel when App2 returns only hidden lifecycle events, and reports queued sessions accurately in the host-facing tool response.
- Keeps support polling, message delivery, end, and reopen tools app-only so MCP hosts do not expose or autonomously invoke the widget's internal chat plumbing.
- Redesigns the embedded support widget with a content-sized transcript, state-aware identity and status, collapsed context, an accessible session menu, a safer end flow, a compact composer, short references, and complete waiting, typing, reconnecting, failure, no-agent, and ended states.
- Shows the support-offer reason once in the dedicated "Why support was offered" card, removing the duplicate header chip and info-popover context.
- Accepts App2 manual-offer trigger IDs without requiring them to exist in the policy-trigger list, preserves the offered reason when opening the chat, and accepts legacy trigger-ID field names.
- Makes `issue_summary` optional for `request_assistance` and publishes explicit `accept_arguments` with every offer so MCP hosts can call the acceptance tool reliably.

## 0.9.8

- Bounds manual-offer lookup latency, fails open on provider timeout/failure/malformed data, and caches valid late offers without weakening blocking or consent semantics.
- Separates credential-derived vendor tenancy from expanded customer identity; deprecated caller-supplied `tenantId` is accepted temporarily but ignored and never transmitted.
- Adds runtime schemas for configuration, identity, offers, remote policies, control-plane data, and shadow reasoning recommendations.
- Adds payload-free diagnostics for provider, validation, telemetry queue, retry, authentication, and drop failures.
- Adds a replaceable, shadow-only assistance reasoning provider interface with a deterministic fake, timeout, cancellation, and validation.
- Adds clean packed-consumer verification covering npm packaging, public imports, one-call setup, instrumentation, MCP App registration, exports, and declarations.

## 0.9.7

- Redesigns the embedded support chat around the assigned human representative, vendor identity, handoff context, quieter message styling, personalized waiting and composer states, reliable typing/read signals, and distinct user-ended and representative-resolved outcomes.

## 0.9.6

- Relays the exact App2 manual-offer message in the model-visible MCP tool result and exposes it as `support_offer_message` structured data.


## 0.9.5

- Fixes telemetry delivery by treating the configured endpoint as the complete App2 ingestion URL instead of appending a second, invalid path.


- Reports the actual SDK release in the telemetry transport user agent.
- Adds pre-tag CI for the SDK and app2, including manifest validation, typechecks, tests, builds, and package inspection.
- Adds atomic release preparation and a single shared SDK version source.
- Uses deterministic pnpm lockfiles and cached installs in CI and publishing.
- Serializes npm publishing and avoids rerunning `prepack` checks during the trusted-publishing step.
- Makes app2 install the npm `latest` dist-tag so SDK releases no longer require app version edits.
- Limits Render auto-deploys to runtime app2 files and waits for GitHub checks to pass.

## 0.9.4

- Publishes the decision-state blocking and manual assistance offer improvements through npm Trusted Publishing without provenance, which npm does not support for private GitHub source repositories.
- Repairs the malformed `package.json` created while preparing the unpublished `0.9.3` tag.
- Pins the app2 Integrations onboarding command and displayed release to `@supportbridge/sdk@0.9.4`.

## 0.9.3

- Returns proactive `block_and_offer` matches as successful `awaiting_user_decision` states instead of MCP tool errors, without executing the business handler.
- Adds explicit accept/decline routing, retry-after-decline metadata, and `do_not_retry_or_bypass` guidance for blocking offers.
- Preserves genuine business-tool failures as errors, including repeated-failure support context.
- Keeps `require_acknowledgement` non-blocking so original content and structured data remain available alongside the assistance notice.
- Pins the app2 Integrations onboarding command and displayed release to `@supportbridge/sdk@0.9.3`.
- Updates the trusted-publishing workflow to Node.js 24 and npm 11, as required for npm OIDC publishing.
- Publishes through OIDC without Sigstore provenance because npm does not support provenance for private GitHub source repositories.

## 0.9.2

- GitHub release only; npm accepted OIDC but rejected provenance because the source repository is private.

## 0.9.1

- GitHub release only; npm publication was rejected before package creation because the original workflow's Node.js/npm versions did not support npm trusted publishing.

## 0.9.0

- Adds tenant-scoped live visitor activity for successful and failed MCP calls.
- Adds manual assistance offers from the control plane, delivered on the targeted user's next tool call.
- Supports representative assignment, acknowledgement behavior, expiry, and single-use delivery.

## 0.8.1

- Versioned the embedded chat resource URI so MCP hosts refresh the redesigned UI instead of reusing a cached pre-0.8 chat document.

## 0.8.0

- Redesigned the embedded support chat with distinct customer/support messages, representative identity, compact mode, quieter system activity, unread indicators, multiline composing, delivery feedback, and responsive styling.
- Replaced technical Slack identifiers in the customer-facing header with human-readable presence and conversation status.
- Added explicit close and reopen states, including a control-plane reopen endpoint and MCP App tool.
- Improved ticket-detail privacy by moving the conversation identifier into an optional details menu.

## 0.7.0

- Added `require_acknowledgement`, a non-blocking policy action that returns business data while appending a visible, consent-safe assistance offer.
- Added explicit pending offer metadata and control-plane lifecycle persistence for pending, presented, accepted, declined, and expired offers.
- Added the acknowledgement action to the dashboard and natural-language policy compiler.
- Preserved the existing metadata-only offer and blocking decision modes for backward compatibility.
- Added optional Slack notifications for new live-help chats and new customer messages in existing chats.

## 0.6.0

- Added representative availability as a control-plane policy eligibility condition.
- Added the mock Sarah representative with Available, Away, and Offline dashboard presence.
- Added `request_assistance` for accepted sales and customer-success assistance offers.
- Automatically assigns accepted assistance requests to the policy's representative.

# 0.5.0

- Added the canonical SupportBridge policy schema, approved field/action registries, deterministic validation and evaluation, nested Boolean conditions, explanations, conflict analysis, decision traces, dry runs, event-loop prevention, and idempotent action execution.
- Added a vendor-neutral NLP provider contract and deterministic fake compiler for local development and tests.
- Added approval, immutable version, disable, rollback, diff, test-case, and audit lifecycle primitives.
- Added the embedded Claude policy-builder MCP App with AI/manual authoring modes, canonical preview, validation, and read-only simulation.

## 0.4.0

- Ported the MCP App lifecycle, metadata, session shape, and UI behavior from the known-working `ballyhoogroup/supportbridge` connector.
- Added the proven `open_support_chat`, `support_get_messages`, `support_send_message`, and `support_end_session` contract.
- Added preferred-frame resource metadata and the working inline display capability handshake.
- Added a compatibility fixture and conformance assertions to prevent drift from the working connector.
- Connected the proven chat lifecycle to the external multi-tenant control plane.

## 0.3.1

- Added a model-visible, MCP-App-linked `talk_to_support` tool.
- Added reopening of an existing ticket by ID so a missing or scrolled-away widget can be rendered again.
- Ensured new and reopened chats return the state required by the embedded app.

## 0.3.0

- Added one-call installation for the official TypeScript MCP SDK.
- Added automatic support-tool, MCP App resource, chat-handler, policy-sync, and shutdown registration.
- Added a single shared identity resolver and automatic recent-tool ticket briefs.
- Added installation capability telemetry, dashboard connection status, and `supportbridge doctor`.

## 0.2.0

- Added a portable MCP App resource for embedded SupportBridge live chat.
- Added ticket creation to `accept_support_offer` when a control-plane client is supplied.
- Added app-only chat refresh and message handlers with a text fallback for non-App hosts.

## 0.1.0

- Added framework-neutral tool-call instrumentation and MCP result adaptation.
- Added sanitized, bounded telemetry with buffered HTTP delivery.
- Added argument-match and repeated-failure support triggers.
- Added blocking support offers with accept, dismiss, and reset state.
- Added optional agent and model spans with async trace propagation.
- Added pluggable telemetry transports and trigger-state stores.
- Added remote policy synchronization and support-chat control-plane client.
- Added a tenant-scoped vendor control plane with Live Streams, Visitor 360, chat, and policy management.
