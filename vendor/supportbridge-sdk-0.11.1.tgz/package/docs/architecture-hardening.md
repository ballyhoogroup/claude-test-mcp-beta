# SDK architecture hardening

`SupportBridgeClient` remains the stable public facade. The focused modules behind it separate business-tool instrumentation from optional SupportBridge dependencies:

- `instrumentation/result-classifier.ts` classifies business-tool outcomes.
- `activity/recent-activity-store.ts` retains bounded, sanitized activity for support briefs.
- `offers/` owns the replaceable offer-provider contract, latency budget, and late-offer cache.
- `schemas/` validates configuration, customer identity, offers, remote triggers, and control-plane responses.
- `diagnostics/` defines payload-free operational diagnostics.
- `providers/reasoning-provider.ts` defines the shadow-only reasoning seam and deterministic fake.
- `transport.ts` preserves the existing public transport classes while reporting queue, retry, authentication, and drop failures.

## Business-tool latency boundary

Offer lookup races a configurable short deadline. Timeout, rejection, and malformed responses return no offer, emit a safe diagnostic, and allow the vendor handler to run. A provider receives an optional `AbortSignal`. If it ignores cancellation and later returns a valid offer, the SDK can consume that offer on the next invocation for the same customer/provider pair.

This behavior does not alter a valid offer. `blocking`, acknowledgement, consent, and retry fields are schema-validated and preserved exactly.

## Identity and tenancy

Customer identity fields are `userId`, `accountId`, `workspaceId`, `organizationId`, `sessionId`, and sanitized primitive traits. These fields may scope customer activity but never select a SupportBridge vendor.

The backend derives vendor ownership from the authenticated API credential. Deprecated `tenantId` remains accepted at the TypeScript boundary for a compatibility period, but runtime normalization removes it from telemetry, state keys, offer requests, and ticket requests.

## Reasoning provider boundary

An `AssistanceReasoningProvider` returns only this validated shape:

```ts
{
  mode: "shadow";
  decision: "offer" | "monitor" | "none";
  confidence: number;
  reasonCode: string;
  recommendedRole: string | null;
  summary: string;
  signals: string[];
  createsIntervention: false;
}
```

Use `recommendAssistance(provider, input, { timeoutMs, signal, diagnostics })` to enforce validation, timeout, and cancellation. The helper does not modify trigger state, create a ticket, generate a customer-facing offer, or contact a representative. No production AI provider is included in this release.

## Diagnostics and privacy

Diagnostics contain a stable code, static safe message, timestamp, and optional primitive operational counters such as status, timeout, attempts, or dropped-event count. Provider errors and validation results never copy raw payloads into diagnostics. Telemetry delivery diagnostics are sent to the configured sink rather than recursively enqueued into a failing telemetry transport.

## Packaged-consumer verification

`npm run test:consumer` builds the package, runs `npm pack`, installs the tarball and MCP peer dependency in a temporary clean project, imports the documented entry point, constructs a minimal MCP server, uses one-call installation and an instrumented business tool, verifies MCP tools/resources, and checks package exports and declarations. The temporary fixture and tarball are removed in a `finally` block. The command does not publish anything.
