# Telemetry contract

All events include `eventId`, `type`, `timestamp`, `source`, `environment`, and `sdkVersion`. When available, they also include `traceId`, `spanId`, `parentSpanId`, `runId`, `requestId`, `serviceVersion`, and a sanitized identity.

## Tool calls

`tool_call` records the tool name, start and end time, duration, outcome, sanitized arguments, a bounded result summary, and normalized error details. Tool events can also include a support offer and the trigger that produced it.

## Agent runs

`agent_run` records the agent name, timing, status, and optional metadata. Prompt or response content is collected only when `captureAgentContent` is enabled.

## Model calls

`model_call` records provider, model, timing, status, token counts, and optional error details. Input and output content follow the same explicit opt-in rule as agent content.

## Delivery

Events are queued in memory and sent in JSON batches:

```json
{
  "events": []
}
```

The HTTP transport sends `content-type: application/json`, `user-agent: supportbridge-sdk/0.1.0`, and, when configured, `authorization: Bearer <apiKey>`. A non-2xx response is retried by the buffered transport up to its configured limit. Delivery failures do not change the vendor tool result.

Event types are exported from the package so a backend can validate and persist the same contract without depending on internal implementation files.
